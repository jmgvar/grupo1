export class Login {
    login: string;
    password: string;
}