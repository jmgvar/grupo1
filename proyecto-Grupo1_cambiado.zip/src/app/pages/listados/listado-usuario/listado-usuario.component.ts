import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listado-usuario',
  templateUrl: './listado-usuario.component.html',
  styleUrls: ['./listado-usuario.component.css']
})
export class ListadoUsuarioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
