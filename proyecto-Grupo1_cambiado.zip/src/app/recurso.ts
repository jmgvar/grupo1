export class Recurso {
    id: number;
    name: string;
    year: number;
    color: string;
    pantone_value: string;
}